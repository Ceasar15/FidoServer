**To remove a tag key from a resource**

The following ``untag-resource`` example removes the tag ``MyTag`` and its value from the thing group ``LightBulbs``. ::

    command

This command produces no output.

For more information, see `Tagging Your AWS IoT Resources <https://docs.aws.amazon.com/iot/latest/developerguide/tagging-iot.html>`__ in the *AWS IoT Developer Guide*.
