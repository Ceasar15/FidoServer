**To delete your registration cod**

The following ``delete-registration-code`` example deletes an AWS IoT account-specific registration code. ::

    aws iot delete-registration-code

This command produces no output.

For more information, see `Use Your Own Certificate <https://docs.aws.amazon.com/iot/latest/developerguide/device-certs-your-own.html>`__ in the *AWS IoT Developer Guide*.
