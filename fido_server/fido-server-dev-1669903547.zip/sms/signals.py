from django.dispatch import Signal  # type: ignore


post_send = Signal()
